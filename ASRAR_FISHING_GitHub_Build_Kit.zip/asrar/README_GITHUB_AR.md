# ASRAR FISHING — بناء APK عبر GitHub Actions

## الخطوات من الهاتف
1. فك ضغط ملف المشروع على هاتفك.
2. افتح https://github.com وأنشئ مستودعًا جديدًا باسم `ASRAR-FISHING` واجعله Public أو Private.
3. من صفحة المستودع اختر Add file ثم Upload files، وارفع **محتويات المجلد** (بما فيها مجلد `.github` وملفاته)، وليس ملف ZIP نفسه.
4. اضغط Commit changes.
5. افتح تبويب Actions في المستودع، ثم افتح تشغيل `Build ASRAR FISHING APK`.
6. انتظر حتى يصبح التشغيل أخضر. افتح تفاصيل التشغيل وانزل إلى Artifacts، ثم نزّل `ASRAR-FISHING-debug-apk`.
7. فك ضغط ملف Artifact؛ ستجد `app-debug.apk`. افتحه على هاتفك واسمح بالتثبيت من هذا المصدر عند طلب Android.

## ملاحظات
- هذا يبني نسخة Debug للتجربة والتثبيت، وليس نسخة متجر Google Play موقعة للنشر.
- لا ترفع كلمات مرور أو مفاتيح توقيع إلى المستودع.
- يجب رفع بنية المشروع كاملة كما هي: `app/`, `build.gradle`, `settings.gradle`, `gradle.properties`, و`.github/workflows/android.yml`.
- إذا ظهر خطأ في Actions، أرسل صورة سجل الخطأ أو انسخ آخر 30 سطرًا منه.
