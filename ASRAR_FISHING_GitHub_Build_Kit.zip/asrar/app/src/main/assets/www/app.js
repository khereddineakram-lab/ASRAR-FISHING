const algerianAnglerNames = {"Sparus aurata": "الدوراد / الدنيس / الوراطة", "Dicentrarchus labrax": "اللوب / القاروص", "Diplodus sargus": "الشرغو", "Mullus barbatus": "الروجي / البربوني", "Dentex dentex": "الدنتكس / السنّار", "Epinephelus marginatus": "المرڨو / الهامور", "Sardina pilchardus": "السردين", "Sphyraena sphyraena": "العنڨليس / البراكودا", "Boops boops": "البوقة", "Lithognathus mormyrus": "المرمار", "Sarpa salpa": "الساربا / السار", "Diplodus vulgaris": "الشرغو المخطط / السار", "Diplodus cervinus": "الدبلودوس المخطط", "Diplodus puntazzo": "الدبلودوس ذو المنقار", "Diplodus annularis": "الدبلودوس الحلقي", "Oblada melanura": "الأوبلاد", "Pagellus erythrinus": "الباجو الأحمر", "Pagellus acarne": "الباجو الأبيض", "Pagrus pagrus": "الباجري", "Spondyliosoma cantharus": "الكانثار", "Serranus cabrilla": "السيرّانوس", "Serranus scriba": "السيرّانوس الملون", "Scorpaena porcus": "السكورپين / سمكة العقرب", "Scorpaena scrofa": "العقرب الحمراء", "Mullus surmuletus": "الروجي المخطط", "Mugil cephalus": "المول / البوري", "Chelon labrosus": "البوري شفاه غليظة", "Chelon auratus": "المول الذهبي", "Chelon saliens": "البوري رفيع الشفاه", "Belone belone": "سمكة الإبرة / لاغويّ", "Pomatomus saltatrix": "البونيت / السمكة الزرقاء", "Seriola dumerili": "السريولا / اللامبوكا (تسمية محلية قد تختلف)", "Trachurus trachurus": "الشورو / الشنشارد", "Scomber colias": "الماكرو / الإسقمري", "Xiphias gladius": "أبو سيف / السيف", "Zeus faber": "سان بيار", "Solea solea": "سمكة موسى", "Octopus vulgaris": "الأخطبوط / المون", "Sepia officinalis": "السيبيا / الحبار"};
const content=document.getElementById('content');
const pages={
 fish:['🐠 دليل الأسماك','الشرغو، القاروص، الوراطة، الميرلان والتونة من أشهر أسماك البحر المتوسط. أضف لاحقاً معلومات الطُعم والموسم وطريقة الصيد لكل نوع.'],
 sea:['🌊 حالة البحر','ستُضاف هنا بيانات الرياح وارتفاع الأمواج ودرجة الحرارة بعد ربط مصدر طقس بحري مباشر. تحقّق دائماً من النشرات الرسمية قبل الخروج.'],
 spots:['📍 أماكن الصيد','يمكنك حفظ أسماء شواطئ وموانئ ومناطق الصيد المفضلة. لا تشارك مواقع حساسة أو خاصة دون إذن.'],
 log:['📸 سجل الصيد','سجّل تاريخ الرحلة، نوع السمكة، الوزن، والطُعم المستخدم. احتفظ بصور صيداتك وذكرياتك البحرية.']
};
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>{const p=pages[b.dataset.page];content.innerHTML=`<h2>${p[0]}</h2><p>${p[1]}</p>`;content.scrollIntoView({behavior:'smooth',block:'nearest'});}));
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js'));
let installPrompt;const installBtn=document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;installBtn.hidden=false;});
installBtn.addEventListener('click',async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;installBtn.hidden=true;});
const coastalWilayas=['تلمسان','عين تموشنت','وهران','مستغانم','الشلف','تيبازة','الجزائر العاصمة','بومرداس','تيزي وزو','بجاية','جيجل','سكيكدة','عنابة','الطارف'];
const coastBox=document.getElementById('coasts');
coastalWilayas.forEach(name=>{const b=document.createElement('button');b.className='coast';b.textContent=name;b.addEventListener('click',()=>{document.querySelectorAll('.coast').forEach(x=>x.classList.remove('active'));b.classList.add('active');content.innerHTML=`<h2>📍 ${name}</h2><p>تم اختيار ساحل ${name}. في التحديث القادم ستضاف نقاط الصيد، أنواع الأسماك، وحالة البحر الخاصة بهذه المنطقة.</p>`;content.scrollIntoView({behavior:'smooth',block:'nearest'});});coastBox.appendChild(b);});

// صور فوتوغرافية من Wikimedia Commons؛ راجع صفحة المصدر لمعرفة ترخيص كل ملف.
const fishData=[
{name:'الدوراد / الدنيس',fr:'Daurade royale',latin:'Sparus aurata',file:'Sparus aurata, 3VPP 8P, Marsa Ben M\'Hidi, Algérie imported from iNaturalist photo 267785627.jpg',source:'https://commons.wikimedia.org/wiki/Category:Sparus_aurata',places:'الخلجان الرملية، الموانئ، مناطق الأعشاب البحرية على امتداد الساحل؛ الوجود يختلف محلياً.',bait:'الدود البحري، بلح البحر، القريدس، قطع السلطعون.',rig:'مونتاج قاع بخطاف أو خطافين وخيط رفيع مناسب لحجم السمكة.',image:'https://commons.wikimedia.org/wiki/Special:FilePath/Sparus%20aurata%2C%203VPP%208P%2C%20Marsa%20Ben%20M%27Hidi%2C%20Alg%C3%A9rie%20imported%20from%20iNaturalist%20photo%20267785627.jpg'},
{name:'القاروص / لوب',fr:'Bar européen',latin:'Dicentrarchus labrax',file:'Dicentrarchus labrax.jpeg',source:'https://commons.wikimedia.org/wiki/Category:Dicentrarchus_labrax',places:'قرب مصبات الأودية، الموانئ، الشواطئ الصخرية والرملية والمياه المضطربة.',bait:'سمك صغير حي أو طازج، روبيان، طعوم صناعية سطحية وغاطسة.',rig:'سبينينغ بطُعم صناعي أو مونتاج منزلق بطُعم طبيعي.',image:'https://commons.wikimedia.org/wiki/Special:FilePath/Dicentrarchus%20labrax.jpeg'},
{name:'الشرغو',fr:'Sar commun',latin:'Diplodus sargus',file:'Diplodus sargus (Linnaeus, 1758).jpg',source:'https://commons.wikimedia.org/wiki/Category:Diplodus_sargus',places:'الشعاب والصخور والحواف المختلطة بالصخر والرمل قرب الشاطئ.',bait:'الدود البحري، القريدس، بلح البحر، السلطعون الصغير.',rig:'مونتاج قاع بسيط أو paternoster بخطاف مناسب.',image:'https://commons.wikimedia.org/wiki/Special:FilePath/Diplodus%20sargus%20%28Linnaeus%2C%201758%29.jpg'},
{name:'البربوني الأحمر',fr:'Rouget de vase',latin:'Mullus barbatus',file:'Mullus barbatus - Julien Renoult - 585826858.jpeg',source:'https://commons.wikimedia.org/wiki/Category:Mullus_barbatus',places:'القاع الرملي والطيني ومناطق الرواسب، غالباً بعيداً قليلاً عن الصخور.',bait:'قطع صغيرة من الدود البحري أو القريدس.',rig:'مونتاج قاعي خفيف بخطاف صغير وطُعم قريب من القاع.',image:'https://commons.wikimedia.org/wiki/Special:FilePath/Mullus%20barbatus%20-%20Julien%20Renoult%20-%20585826858.jpeg'},
{name:'الدنتكس',fr:'Denté commun',latin:'Dentex dentex',file:'Dentex dentex.jpg',source:'https://commons.wikimedia.org/wiki/Category:Dentex_dentex',places:'المناطق الصخرية العميقة والحواف البحرية؛ قد يوجد بعيداً عن الشاطئ.',bait:'حبار، سردين، سمك صغير طازج أو حي حيث يسمح القانون.',rig:'صيد قاعي قوي أو جرّ بالطُعم الصناعي من قارب مع معدات ملائمة.',image:'https://commons.wikimedia.org/wiki/Special:FilePath/Dentex%20dentex.jpg'},
{name:'الهامور',fr:'Mérou brun',latin:'Epinephelus marginatus',file:'Dusky grouper (Epinephelus marginatus).jpg',source:'https://commons.wikimedia.org/wiki/Category:Epinephelus_marginatus',places:'الكهوف والشقوق والشعاب الصخرية؛ غالباً في مناطق صخرية أعمق.',bait:'حبار أو أخطبوط وقطع سمك؛ مع مراعاة القيود القانونية وأحجام الصيد.',rig:'مونتاج قاعي متين قرب الصخور مع تجنب ترك الخيط عالقاً.',image:'https://commons.wikimedia.org/wiki/Special:FilePath/Dusky%20grouper%20%28Epinephelus%20marginatus%29.jpg'},
{name:'السردين',fr:'Sardine',latin:'Sardina pilchardus',file:'Sardina pilchardus.jpg',source:'https://commons.wikimedia.org/wiki/Category:Sardina_pilchardus',places:'أسراب في المياه الساحلية والسطحية، وتتغير مواقعها مع الموسم والتيارات.',bait:'يُستخدم طُعماً لأسماك مفترسة؛ ويمكن استهدافه بشباك أو سنارة متعددة صغيرة وفق القوانين.',rig:'ريشة/سابيكي بخطافات صغيرة عند ظهور السرب.',image:'https://commons.wikimedia.org/wiki/Special:FilePath/Sardina%20pilchardus.jpg'},
{name:'البراكودا',fr:'Bécune / Barracuda',latin:'Sphyraena sphyraena',file:'Sphyraena sphyraena.jpg',source:'https://commons.wikimedia.org/wiki/Category:Sphyraena_sphyraena',places:'المياه الساحلية المفتوحة وحواف الخلجان ومناطق مرور الأسماك الصغيرة.',bait:'طعوم صناعية طويلة، أو سمكة صغيرة طازجة؛ استخدم وصلة مقاومة للأسنان.',rig:'سبينينغ بطُعم طويل مع وصلة سلكية أو مقاومة للقطع.',image:'https://commons.wikimedia.org/wiki/Special:FilePath/Sphyraena%20sphyraena.jpg'}
];
const fishCatalog=document.getElementById('fishCatalog');
fishData.forEach(f=>{const c=document.createElement('article');c.className='fish-card';c.innerHTML=`<img class="photo" loading="lazy" src="${f.image}" alt="صورة حقيقية لسمكة ${f.name}" onerror="this.src='https://placehold.co/700x400/e8f6fb/063b59?text=Fish+photo'"><div class="fish-body"><h3>${f.name}</h3><div class="angler-name">🎣 الاسم عند الصيادين: ${algerianAnglerNames[f.latin] || f.name}</div><div class="latin">${f.fr} · ${f.latin}</div><p><b>📍 أماكن التواجد:</b> ${f.places}</p><p><b>🪱 الطُعم:</b> ${f.bait}</p><p><b>🎣 طريقة الصيد:</b> ${f.rig}</p><a href="${f.source}" target="_blank" rel="noopener">مصدر الصورة وحقوق استخدامها</a></div>`;fishCatalog.appendChild(c);});
const rigData=[['مونتاج القاع المتعدد','assets/paternoster.svg'],['الرصاصة المنزلقة','assets/sliding.svg'],['السبينينغ بالطُعم الصناعي','assets/spinning.svg']];
const rigBox=document.getElementById('rigs');rigData.forEach(r=>{const c=document.createElement('article');c.className='rig-card';c.innerHTML=`<img loading="lazy" src="${r[1]}" alt="${r[0]}"><h3>${r[0]}</h3>`;rigBox.appendChild(c);});
const saveCatch=document.getElementById('saveCatch');saveCatch.addEventListener('click',()=>{const name=document.getElementById('catchName').value.trim()||'صيدتي';const file=document.getElementById('catchPhoto').files[0];if(!file){alert('اختر صورة للصيدة أولاً');return;}const reader=new FileReader();reader.onload=()=>{const card=document.createElement('div');card.className='catch-card';const img=document.createElement('img');img.src=reader.result;const p=document.createElement('p');p.textContent=name;card.append(img,p);document.getElementById('catchWall').prepend(card);};reader.readAsDataURL(file);});


// 30 نوعاً إضافياً موثقاً ضمن قوائم الأسماك المسجلة على الساحل الجزائري؛
// الصور تُحمّل من Wikimedia Commons عبر صفحة الملف/الاسم العلمي وقد تختلف أسماء الملفات.
const moreFish=[
['البوقة','Bogue','Boops boops','المياه الساحلية وأسراب منتصف الماء قرب الأعشاب والصخور','دود بحري صغير، قطع روبيان، عجينة طُعم','سابيكي صغير أو مونتاج خفيف بخطافات صغيرة'],
['المرمار','Sand steenbras','Lithognathus mormyrus','القاع الرملي والمناطق المختلطة بالرمل قرب الشاطئ','دود الرمل، الدود البحري، القريدس','مونتاج قاعي بخطاف صغير قريب من القاع'],
['الساربا','Salema','Sarpa salpa','مروج البوسيدونيا والأعشاب البحرية والمناطق الصخرية الضحلة','طحالب بحرية وخبز وعجائن نباتية بحسب الظروف','عوامة خفيفة أو قاع خفيف؛ لا تستخدم طُعماً نباتياً إلا حيث يناسب'],
['الدوراد الأسود / السار','White seabream','Diplodus vulgaris','الصخور والحواف الرملية الصخرية قرب الساحل','دود بحري، قريدس، بلح البحر','مونتاج قاعي paternoster أو خطاف مفرد'],
['الدبلودوس المخطط','Zebra seabream','Diplodus cervinus','الشعاب الصخرية والحواف العميقة نسبياً','قريدس، سلطعون صغير، بلح البحر','مونتاج قاعي متين قرب الصخور'],
['الدبلودوس ذو المنقار','Sharpsnout seabream','Diplodus puntazzo','المناطق الصخرية ومروج الأعشاب البحرية','بلح البحر، قريدس، ديدان','قاع خفيف أو عوامة حسب العمق والتيار'],
['الدبلودوس الحلقي','Annular seabream','Diplodus annularis','الأعشاب البحرية والقاع الرملي الضحل','دود بحري، قطع قريدس صغيرة','مونتاج قاعي خفيف بخطاف صغير'],
['الأوبلاد','Saddled seabream','Oblada melanura','المياه الساحلية قرب الصخور والأعشاب وأحياناً قرب السطح','خبز، عجينة، قطع سردين صغيرة','عوامة أو سابيكي خفيف'],
['الباجو الأحمر','Common pandora','Pagellus erythrinus','القاع الرملي والطيني وحواف الصخور','دود بحري، قريدس، شرائح حبار','مونتاج قاعي بخطاف متوسط'],
['الباجو الأبيض','Axillary seabream','Pagellus acarne','القاع الرملي والطيني والمناطق الساحلية الأعمق','دود بحري، قريدس، قطع حبار','مونتاج قاعي خفيف إلى متوسط'],
['الباجري','Common dentex / Pagrus','Pagrus pagrus','القاع الصخري والرمل المختلط والحواف البحرية','حبار، قريدس، سلطعون، سمك صغير','مونتاج قاعي قوي أو صيد بالقارب'],
['الكانثار','Black seabream','Spondyliosoma cantharus','المناطق الصخرية ومروج الأعشاب والقاع المختلط','دود بحري، قريدس، بلح البحر','قاع خفيف أو عوامة'],
['السيرّانوس','Comber','Serranus cabrilla','الشعاب الصخرية والركائز المختلطة؛ مسجل في خليج عنابة','دود، قريدس صغير، قطع سمك','مونتاج قاعي صغير بخطاف مناسب'],
['السيرّانوس الملون','Painted comber','Serranus scriba','الصخور ومروج الأعشاب البحرية قرب القاع','دود بحري وقريدس وقطع صغيرة','قاع خفيف بخطاف صغير'],
['سمكة العقرب السوداء','Black scorpionfish','Scorpaena porcus','الشقوق الصخرية والطحالب وقرب القاع','قريدس، قطع سمك، دود','قاع قريب من الصخور؛ احذر الأشواك السامة ولا تلمسها'],
['سمكة العقرب الحمراء','Red scorpionfish','Scorpaena scrofa','القاع الصخري والشعاب والكهوف البحرية','قريدس وقطع سمك وحبار','قاع متين؛ تعامل بحذر شديد بسبب الأشواك'],
['البربوني المخطط','Striped red mullet','Mullus surmuletus','القاع الرملي والصخري ومروج الأعشاب','دود بحري، قريدس صغير','مونتاج قاعي خفيف قريب من القاع'],
['البوري الرمادي','Flathead grey mullet','Mugil cephalus','الموانئ والخلجان ومصبات المياه والبحيرات الساحلية','خبز وعجائن نباتية وطحالب حسب المكان','عوامة وخيط رفيع وطُعم صغير'],
['البوري الشفاهي','Thicklip grey mullet','Chelon labrosus','المرافئ والخلجان والمياه الساحلية الضحلة','خبز، عجينة، طحالب','عوامة خفيفة وخطاف صغير'],
['البوري الذهبي','Golden grey mullet','Chelon auratus','الشواطئ الرملية والخلجان والبحيرات الساحلية','خبز وعجينة وطحالب','عوامة خفيفة أو قاع خفيف'],
['البوري رفيع الشفاه','Thinlip grey mullet','Chelon saliens','المياه الساحلية والبحيرات والمناطق الشروب','خبز وعجائن نباتية','عوامة خفيفة'],
['سمكة الإبرة','Garfish','Belone belone','قرب السطح في المياه الساحلية والخلجان المفتوحة','قطع سمك صغيرة وشرائط سمك وطُعم صناعي صغير','عوامة سطحية أو سبينينغ خفيف؛ انتبه للفك والأسنان'],
['البونيتو / السمكة الزرقاء','Bluefish','Pomatomus saltatrix','المياه المفتوحة قرب الساحل ومطاردة أسراب السردين','سردين وسمك صغير وطعوم صناعية معدنية','سبينينغ بخيط قوي وقائد مقاوم للأسنان'],
['السريولا','Greater amberjack','Seriola dumerili','المياه المفتوحة وحواف الشعاب العميقة حول الجزر والرؤوس','سمك حي أو حبار وطُعم صناعي ثقيل','جِغّينغ أو قاع بالقارب بمعدات قوية'],
['الشورو','Atlantic horse mackerel','Trachurus trachurus','أسراب في المياه الساحلية والمتوسطة العمق','ريش صناعية صغيرة وقطع سردين','سابيكي متعدد الخطافات'],
['الإسقمري','Atlantic chub mackerel','Scomber colias','المياه المفتوحة وأسراب قرب السطح','ريش صغيرة، سابيكي، طُعم صناعي معدني','سابيكي أو سبينينغ خفيف'],
['أبو سيف','Swordfish','Xiphias gladius','المياه البحرية المفتوحة والعميقة؛ صيده يخضع لتنظيمات خاصة','يُستهدف بمعدات قوارب متخصصة؛ ليس صيد شاطئ اعتيادياً','لا يُنصح بمونتاج شاطئي؛ التزم بالقوانين والمواسم والتراخيص'],
['سمكة القديس بطرس','John Dory','Zeus faber','القاع الرملي والطيني ومناطق المياه الأعمق','سمك صغير أو شرائح سمك وحبار','قاع بالقارب بخطاف مناسب'],
['سمكة موسى','Common sole','Solea solea','القاع الرملي والطيني والخلجان والبحيرات الساحلية','دود بحري وديدان رملية','قاع خفيف بخطاف صغير جداً'],
['الأخطبوط','Common octopus','Octopus vulgaris','الشقوق والكهوف والشعاب الصخرية؛ من الرخويات وليس سمكة','سلطعون أو طُعم صناعي مخصص للأخطبوط وفق القانون','طُعم أخطبوط/توتانيرا من قارب أو رصيف؛ راعِ المواسم والأحجام'],
['الحبار','Common cuttlefish','Sepia officinalis','القاع الرملي والأعشاب البحرية والخلجان؛ من رأسيات الأرجل','طُعم صناعي إكِّي أو سمك صغير','إكِّي / سبيط صناعي ببطء قرب القاع']
];
const moreCatalog=document.getElementById('fishCatalog');
moreFish.forEach(f=>{
 const [ar,fr,latin,places,bait,rig]=f;
 const url='https://commons.wikimedia.org/wiki/Special:FilePath/'+encodeURIComponent(latin.replaceAll(' ','_')+'.jpg');
 const category='https://commons.wikimedia.org/wiki/Category:'+encodeURIComponent(latin.replaceAll(' ','_'));
 const c=document.createElement('article');c.className='fish-card';
 c.innerHTML=`<img class="photo" loading="lazy" src="${url}" alt="صورة ${ar}" onerror="this.style.display='none'"><div class="fish-body"><h3>${ar}</h3><div class="angler-name">🎣 الاسم عند الصيادين: ${algerianAnglerNames[latin] || ar}</div><div class="latin">${fr} · ${latin}</div><p><b>📍 أماكن التواجد:</b> ${places}</p><p><b>🪱 الطُعم:</b> ${bait}</p><p><b>🎣 المونتاج:</b> ${rig}</p><a href="${category}" target="_blank" rel="noopener">ابحث عن صور النوع في Wikimedia Commons</a></div>`;
 moreCatalog.appendChild(c);
});


// قاموس محلي تعاوني على الجهاز: الإضافات لا تُرسل إلى خادم ولا تظهر على أجهزة أخرى.
const localNameForm=document.getElementById('localNameForm');
const localWilaya=document.getElementById('localWilaya');
const localNamesList=document.getElementById('localNamesList');
const localNamesKey='khereddineFishingLocalNamesV1';
coastalWilayas.forEach(w=>{const o=document.createElement('option');o.value=w;o.textContent=w;localWilaya.appendChild(o);});
function readLocalNames(){try{return JSON.parse(localStorage.getItem(localNamesKey)||'[]');}catch{return [];}}
function renderLocalNames(){
 const entries=readLocalNames(); localNamesList.replaceChildren();
 if(!entries.length){const empty=document.createElement('p');empty.className='empty-dictionary';empty.textContent='لم تتم إضافة أسماء محلية بعد. كن أول من يساهم!';localNamesList.appendChild(empty);return;}
 entries.slice().reverse().forEach((entry,index)=>{
  const card=document.createElement('article');card.className='local-name-card';
  const heading=document.createElement('strong');heading.textContent=entry.fish+' ← '+entry.local;
  const meta=document.createElement('span');meta.textContent=entry.wilaya+(entry.note?' · '+entry.note:'');
  const del=document.createElement('button');del.type='button';del.className='remove-name';del.textContent='حذف';del.setAttribute('aria-label','حذف هذا الاسم');
  del.addEventListener('click',()=>{const current=readLocalNames();current.splice(current.length-1-index,1);localStorage.setItem(localNamesKey,JSON.stringify(current));renderLocalNames();});
  card.append(heading,meta,del);localNamesList.appendChild(card);
 });
}
localNameForm.addEventListener('submit',e=>{
 e.preventDefault();const entry={wilaya:localWilaya.value,fish:document.getElementById('fishStandard').value.trim(),local:document.getElementById('fishLocal').value.trim(),note:document.getElementById('nameNote').value.trim()};
 if(!entry.fish||!entry.local)return;
 const entries=readLocalNames();entries.push(entry);
 try{localStorage.setItem(localNamesKey,JSON.stringify(entries));localNameForm.reset();renderLocalNames();}
 catch{alert('تعذر الحفظ في هذا المتصفح. تحقق من مساحة التخزين أو إعدادات الخصوصية.');}
});
renderLocalNames();
